import { RotateCcw, TrendingUp } from 'lucide-react';

const RED_NUMBERS = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];

interface HistoryTickerProps {
  history: number[];
  onClearHistory: () => void;
}

export default function HistoryTicker({ history, onClearHistory }: HistoryTickerProps) {
  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 max-w-5xl mx-auto mb-4">
      {/* Title & Stats Meta */}
      <div className="flex items-center gap-3 shrink-0">
        <div className="w-10 h-10 rounded-xl bg-slate-950 flex items-center justify-center border border-slate-800">
          <TrendingUp className="w-5 h-5 text-indigo-400" />
        </div>
        <div>
          <h2 className="text-xs font-black tracking-widest text-slate-300 uppercase">
            Bandeau de Sortie
          </h2>
          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mt-0.5">
            {history.length} numéro{history.length > 1 ? 's' : ''} tiré{history.length > 1 ? 's' : ''}
          </p>
        </div>
      </div>

      {/* Endless Horizontal Strip */}
      <div className="flex-1 bg-slate-950 rounded-xl border border-slate-850 px-4 py-2.5 overflow-x-auto scrollbar-none flex items-center gap-2">
        {history.length === 0 ? (
          <span className="text-xs text-slate-500 italic block py-0.5 select-none font-medium">
            En attente de tirages... Cliquez sur un numéro du pavé tactile ou des carrés.
          </span>
        ) : (
          history.map((num, idx) => {
            const isRed = RED_NUMBERS.includes(num);
            const isLatest = idx === 0;

            return (
              <div
                key={idx}
                className={`shrink-0 flex items-center justify-center font-bold text-sm w-8 h-8 rounded-full border transition-all relative ${
                  num === 0
                    ? 'bg-emerald-800 border-emerald-900 text-white'
                    : isRed
                    ? 'bg-red-700 border-red-800 text-white'
                    : 'bg-slate-900 border-slate-950 text-slate-100'
                } ${
                  isLatest
                    ? 'ring-2 ring-yellow-400 ring-offset-2 ring-offset-slate-950 scale-110 z-10 animate-fade-in'
                    : 'opacity-80'
                }`}
              >
                {num}
                
                {/* Visual ripple tag for the latest drawn number */}
                {isLatest && (
                  <>
                    <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-yellow-400 animate-ping" />
                    <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-yellow-400 border border-slate-950" />
                  </>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* History Clear Trigger */}
      {history.length > 0 && (
        <button
          onClick={onClearHistory}
          className="px-3.5 py-2.5 rounded-xl border border-slate-800 bg-slate-950 hover:bg-slate-850 hover:text-red-400 text-slate-400 text-xs font-bold transition flex items-center gap-1.5 shrink-0 self-end md:self-auto"
          title="Réinitialiser l'historique complet des tirages"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Effacer l'historique</span>
        </button>
      )}
    </div>
  );
}

import { GridState } from '../types';

export const NUMBERS_LEFT = [
  [31, 22, 29],
  [15, 4, 2],
  [11, 8, 10],
  [28, 35, 26],
  [17, 6, 13],
  [24, 33, 20],
];

export const NUMBERS_RIGHT = [
  [14, 9, 18],
  [32, 19, 21],
  [36, 30, 23],
  [7, 12, 3],
  [25, 34, 27],
  [5, 16, 1],
];

interface SquaresBoardProps {
  leftCells: GridState;
  rightCells: GridState;
  onCellClick: (isRight: boolean, r: number, c: number) => void;
}

export default function SquaresBoard({ leftCells, rightCells, onCellClick }: SquaresBoardProps) {
  
  // Renders a 3x3 subgrid for either left or right cells
  const renderSubgrid = (isRight: boolean, rowStart: number) => {
    const cells = isRight ? rightCells : leftCells;
    const nums = isRight ? NUMBERS_RIGHT : NUMBERS_LEFT;

    return (
      <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-950/25 rounded-xl border border-slate-800/40">
        {Array.from({ length: 3 }).map((_, localRow) => {
          const r = rowStart + localRow;
          return Array.from({ length: 3 }).map((_, c) => {
            const key = `${r}-${c}`;
            const stateColor = cells[key] || 'white';
            const num = nums[r][c];

            let cellClass = '';
            if (stateColor === 'red') {
              cellClass = 'bg-red-700 text-white border-red-800 shadow shadow-red-500/20';
            } else if (stateColor === 'green') {
              cellClass = 'bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-black border-emerald-400 shadow shadow-emerald-500/30 animate-pulse-slow';
            } else {
              cellClass = 'bg-slate-800/90 text-slate-200 border-slate-700 hover:bg-slate-700/80';
            }

            return (
              <button
                key={c}
                onClick={(e) => {
                  e.stopPropagation();
                  onCellClick(isRight, r, c);
                }}
                className={`w-10 h-10 rounded-lg border text-sm font-bold flex items-center justify-center transition active:scale-95 select-none ${cellClass}`}
              >
                {num}
              </button>
            );
          });
        })}
      </div>
    );
  };

  return (
    <div className="flex gap-4 p-2 bg-slate-900/40 rounded-2xl border border-slate-850/60 shadow-lg justify-center max-w-full">
      {/* Left Squares Column */}
      <div className="flex flex-col gap-3">
        <div className="text-[10px] font-black tracking-wide uppercase text-slate-400 text-center select-none">
          Carrés de Gauche
        </div>
        <div className="flex flex-col gap-2.5">
          {renderSubgrid(false, 0)}
          {renderSubgrid(false, 3)}
        </div>
      </div>

      {/* Vertical separator */}
      <div className="w-px bg-slate-800 self-stretch my-2" />

      {/* Right Squares Column */}
      <div className="flex flex-col gap-3">
        <div className="text-[10px] font-black tracking-wide uppercase text-slate-400 text-center select-none">
          Carrés de Droite
        </div>
        <div className="flex flex-col gap-2.5">
          {renderSubgrid(true, 0)}
          {renderSubgrid(true, 3)}
        </div>
      </div>
    </div>
  );
}

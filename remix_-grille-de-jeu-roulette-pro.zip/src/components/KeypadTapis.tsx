import { Star, Flame } from 'lucide-react';

const RED_NUMBERS = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];

// The layout rows of a physical roulette table (from top to bottom visually)
const TAPIS_ROWS = [
  [3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36], // Row 1 (values modulo 3 === 0)
  [2, 5, 8, 11, 14, 17, 20, 23, 26, 29, 32, 35], // Row 2 (values modulo 3 === 2)
  [1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34], // Row 3 (values modulo 3 === 1)
];

interface KeypadTapisProps {
  onNumberSelect: (num: number) => void;
  topTransversales: Array<{ nums: number[]; score: number }>;
  recommendedFulls: number[];
  frequencies: Record<number, number>;
}

export default function KeypadTapis({
  onNumberSelect,
  topTransversales,
  recommendedFulls,
  frequencies,
}: KeypadTapisProps) {
  // Convert top transversals to sets for fast checking
  const topTransvSets = topTransversales.map((t) => new Set(t.nums));
  const recommendedSet = new Set(recommendedFulls);

  // Helper to determine if a specific transversal index (col index + 1) is a top transversal
  // Each column index corresponds directly to a transversal column:
  // Col 0: 1,2,3 (Transv 1)
  // Col 1: 4,5,6 (Transv 2)
  // ...
  const checkColPriority = (colIdx: number) => {
    // Numbers in this column
    const tNumbers = [TAPIS_ROWS[2][colIdx], TAPIS_ROWS[1][colIdx], TAPIS_ROWS[0][colIdx]];
    const matched = topTransversales.some(
      (t) => t.nums.includes(tNumbers[0]) && t.nums.includes(tNumbers[1]) && t.nums.includes(tNumbers[2])
    );
    return matched;
  };

  return (
    <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-4 shadow-xl">
      {/* Active Suggestions Banner / Legend */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <Flame className="w-4 h-4 text-amber-400 fill-amber-500 animate-pulse" />
          <span className="text-xs font-bold text-slate-300 tracking-wide uppercase">
            Top 6 Transversales Prioritaires :
          </span>
        </div>
        
        <div className="flex flex-wrap gap-1.5">
          {topTransversales.length === 0 ? (
            <span className="text-xs text-slate-500 italic">Aucune donnée de tirage pour le moment</span>
          ) : (
            topTransversales.map((t, idx) => (
              <span
                key={idx}
                className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-amber-500/10 border border-amber-500/40 text-amber-300 shadow-sm"
              >
                {t.nums.join('-')} <span className="text-[10px] text-amber-400 font-sans">(×{t.score})</span>
              </span>
            ))
          )}
        </div>

        {recommendedFulls.length > 0 && (
          <div className="flex items-center gap-1.5 ml-auto sm:ml-0">
            <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
              <Star className="w-3.5 h-3.5 fill-emerald-500 text-emerald-400" /> Numéros Pleins Recommandés :
            </span>
            <div className="flex gap-1">
              {recommendedFulls.slice(0, 4).map((n) => (
                <span
                  key={n}
                  onClick={() => onNumberSelect(n)}
                  className="cursor-pointer text-xs font-black w-6 h-6 flex items-center justify-center rounded-full bg-emerald-500/10 border border-emerald-400 text-emerald-300 hover:bg-emerald-500 hover:text-white transition"
                >
                  {n}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Tapis Layout Container */}
      <div className="overflow-x-auto select-none scrollbar-thin">
        <div className="inline-flex gap-1.5 p-1 min-w-[760px]">
          {/* Squeezed 0 Key */}
          <button
            onClick={() => onNumberSelect(0)}
            className="w-12 h-[126px] bg-emerald-800 border-2 border-emerald-950 text-white font-black text-lg rounded-xl hover:bg-emerald-700 hover:border-emerald-500 active:scale-95 transition-all flex flex-col items-center justify-center shadow-md shadow-emerald-900/20"
          >
            <span className="text-xs tracking-wider opacity-60 font-sans mb-1 uppercase font-bold">Zéro</span>
            <span>0</span>
            {frequencies[0] > 0 && (
              <span className="text-[10px] text-emerald-300 font-mono mt-1">({frequencies[0]}×)</span>
            )}
          </button>

          {/* Grid columns (1 to 12 columns of 3 rows) */}
          <div className="flex gap-1 px-1 py-0.5 rounded-xl border border-slate-800 bg-slate-950/40 relative">
            {Array.from({ length: 12 }).map((_, colIdx) => {
              const isPriority = checkColPriority(colIdx);
              return (
                <div
                  key={colIdx}
                  className={`flex flex-col gap-1.5 p-1 rounded-lg transition-all ${
                    isPriority
                      ? 'bg-amber-500/10 border border-amber-500/35 shadow-lg shadow-amber-500/5 glow-effect'
                      : 'border border-transparent'
                  }`}
                >
                  {TAPIS_ROWS.map((rowVals, rowIdx) => {
                    const val = rowVals[colIdx];
                    const isRed = RED_NUMBERS.includes(val);
                    const isRecommended = recommendedSet.has(val);
                    const freq = frequencies[val] || 0;

                    return (
                      <button
                        key={val}
                        onClick={() => onNumberSelect(val)}
                        className={`group relative w-12 h-8 rounded-lg flex flex-col items-center justify-center font-bold text-sm transition-all active:scale-95 shadow border ${
                          isRed
                            ? 'bg-red-700 hover:bg-red-650 border-red-850 text-white'
                            : 'bg-slate-850 hover:bg-slate-750 border-slate-950 text-slate-100'
                        } ${
                          isRecommended
                            ? 'ring-2 ring-emerald-500 shadow-emerald-500/30 font-black'
                            : ''
                        }`}
                      >
                        {/* Number label */}
                        <div className="flex items-center justify-center gap-0.5">
                          {isRecommended && (
                            <Star className="w-2.5 h-2.5 fill-emerald-400 text-emerald-400 inline" />
                          )}
                          <span>{val}</span>
                        </div>

                        {/* Frequency meter */}
                        {freq > 0 && (
                          <span className="text-[8px] font-mono opacity-60 -mt-0.5 text-slate-300">
                            {freq}×
                          </span>
                        )}

                        {/* Indicator highlight */}
                        {isPriority && (
                          <span className="absolute bottom-0 w-4 h-0.5 rounded-full bg-amber-400 shadow-sm shadow-amber-400" />
                        )}
                      </button>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      </div>
      
      {/* Tapis Column Tags */}
      <div className="mt-2 flex justify-between text-[10px] text-slate-500 font-bold px-1 select-none">
        <div className="w-12 text-center">Zéro</div>
        <div className="flex-1 flex justify-around pl-4">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="w-12 text-center text-[9px] font-mono uppercase tracking-wide">
              {checkColPriority(i) ? (
                <span className="text-amber-500 font-bold">★ T{i + 1}</span>
              ) : (
                <span>T{i + 1}</span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

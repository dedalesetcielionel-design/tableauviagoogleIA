import { useEffect, useRef, useState } from 'react';

const ROUE_ORDER = [
  0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 
  10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26
];

const RED_NUMBERS = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];

interface RouletteWheelProps {
  lastDrawnNum: number | null;
  targetNumbers: Set<number>;
  historyCount: number;
}

export default function RouletteWheel({ lastDrawnNum, targetNumbers, historyCount }: RouletteWheelProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // States to hold the animation values
  const [ballAngle, setBallAngle] = useState<number | null>(null);
  const [ballRadius, setBallRadius] = useState<number>(65);
  const [isSpinning, setIsSpinning] = useState<boolean>(false);
  
  const lastNumRef = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    const cx = W / 2;
    const cy = H / 2;
    const R_outer = W / 2 - 4; // 106
    const R_pockets_outer = 90;
    const R_pockets_inner = 72;
    const R_inner_rim = 53;
    const R_center_hub = 22;

    const n = ROUE_ORDER.length;
    const sliceAngle = (2 * Math.PI) / n;
    // Offset so that 0 is exactly at the top center
    const startOffset = -Math.PI / 2 - sliceAngle / 2;

    // Determine target angle for lastDrawnNum
    let targetAngle = 0;
    if (lastDrawnNum !== null) {
      const idx = ROUE_ORDER.indexOf(lastDrawnNum);
      targetAngle = startOffset + idx * sliceAngle + sliceAngle / 2;
    }

    // Handle spin animation if target number changed
    let animId: number;
    if (lastDrawnNum !== null && lastDrawnNum !== lastNumRef.current) {
      // Start spin animation
      lastNumRef.current = lastDrawnNum;
      setIsSpinning(true);
      
      const duration = 1500; // ms
      const startTime = performance.now();
      const spins = 3 + Math.random() * 2; // number of full spins
      const initialBallAngle = ballAngle !== null ? ballAngle : targetAngle - spins * 2 * Math.PI - 1;
      const targetAnimAngle = targetAngle; // final stop

      const animate = (time: number) => {
        const elapsed = time - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Easing function for smooth stop
        // cubic cubic easeOut
        const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
        const tEase = easeOut(progress);

        // Circular interpolation
        const currentAngle = initialBallAngle + (targetAnimAngle - initialBallAngle) * tEase;
        
        // Ball spiral effect - starts at outer rim and drops into pocket
        const currentRadius = 94 - (94 - 81) * tEase;

        setBallAngle(currentAngle);
        setBallRadius(currentRadius);
        
        // Render wheel & animated ball
        drawWheelAndBall(ctx, cx, cy, R_outer, R_pockets_outer, R_pockets_inner, R_inner_rim, R_center_hub, startOffset, sliceAngle, currentAngle, currentRadius);

        if (progress < 1) {
          animId = requestAnimationFrame(animate);
        } else {
          setIsSpinning(false);
          setBallAngle(targetAngle);
          setBallRadius(81); // rests inside pocket
          drawWheelAndBall(ctx, cx, cy, R_outer, R_pockets_outer, R_pockets_inner, R_inner_rim, R_center_hub, startOffset, sliceAngle, targetAngle, 81);
        }
      };

      animId = requestAnimationFrame(animate);
    } else {
      // Draw statically
      const curAngle = lastDrawnNum !== null ? targetAngle : null;
      setBallAngle(curAngle);
      setBallRadius(81);
      drawWheelAndBall(ctx, cx, cy, R_outer, R_pockets_outer, R_pockets_inner, R_inner_rim, R_center_hub, startOffset, sliceAngle, curAngle, 81);
    }

    return () => {
      if (animId) cancelAnimationFrame(animId);
    };
  }, [lastDrawnNum, targetNumbers, historyCount]);

  // Main drawing method
  const drawWheelAndBall = (
    ctx: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    R_outer: number,
    R_pockets_outer: number,
    R_pockets_inner: number,
    R_inner_rim: number,
    R_center_hub: number,
    startOffset: number,
    sliceAngle: number,
    activeBallAngle: number | null,
    activeBallRadius: number
  ) => {
    ctx.clearRect(0, 0, cx * 2, cy * 2);

    // 1. Draw Outer Wooden Rim
    const rimGrad = ctx.createRadialGradient(cx, cy, R_pockets_outer, cx, cy, R_outer);
    rimGrad.addColorStop(0, '#111827');
    rimGrad.addColorStop(0.3, '#374151');
    rimGrad.addColorStop(0.8, '#1f2937');
    rimGrad.addColorStop(1, '#030712');
    
    ctx.beginPath();
    ctx.arc(cx, cy, R_outer, 0, 2 * Math.PI);
    ctx.fillStyle = rimGrad;
    ctx.fill();
    ctx.strokeStyle = '#4b5563';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // 2. Draw outer golden border of the numbers track
    ctx.beginPath();
    ctx.arc(cx, cy, R_pockets_outer, 0, 2 * Math.PI);
    ctx.strokeStyle = '#d97706'; // Gold color border
    ctx.lineWidth = 2;
    ctx.stroke();

    // 3. Draw Slices / Pockets
    ROUE_ORDER.forEach((num, i) => {
      const sa = startOffset + i * sliceAngle;
      const ea = sa + sliceAngle;
      const mid = sa + sliceAngle / 2;
      const isTarget = targetNumbers.has(num);

      // Draw the pocket slice background
      ctx.beginPath();
      ctx.moveTo(cx + R_pockets_inner * Math.cos(sa), cy + R_pockets_inner * Math.sin(sa));
      ctx.lineTo(cx + R_pockets_outer * Math.cos(sa), cy + R_pockets_outer * Math.sin(sa));
      ctx.arc(cx, cy, R_pockets_outer, sa, ea);
      ctx.lineTo(cx + R_pockets_inner * Math.cos(ea), cy + R_pockets_inner * Math.sin(ea));
      ctx.arc(cx, cy, R_pockets_inner, ea, sa, true);
      ctx.closePath();

      // Pocket colors
      let pocketColor = '#1f2937'; // charcoal for black numbers
      if (num === 0) {
        pocketColor = '#15803d'; // green for 0
      } else if (RED_NUMBERS.includes(num)) {
        pocketColor = '#991b1b'; // deep red
      }

      ctx.fillStyle = pocketColor;
      ctx.fill();

      // Highlight target playable numbers with golden overlay / stroke
      if (isTarget) {
        ctx.fillStyle = 'rgba(234, 179, 8, 0.45)';
        ctx.fill();
        ctx.strokeStyle = '#facc15';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      } else {
        ctx.strokeStyle = '#111827';
        ctx.lineWidth = 0.5;
        ctx.stroke();
      }

      // Draw numbers text inside standard or active segments
      ctx.save();
      const trRadius = R_pockets_inner + (R_pockets_outer - R_pockets_inner) / 2;
      ctx.translate(cx + trRadius * Math.cos(mid), cy + trRadius * Math.sin(mid));
      // Rotate numbers outward so they read neatly pointing outwards
      ctx.rotate(mid + Math.PI / 2);
      ctx.fillStyle = isTarget ? '#fde047' : '#ffffff';
      ctx.font = isTarget ? 'bold 8px "JetBrains Mono"' : '500 8px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      
      // Add star dot to recommended targets to make them pop!
      const text = isTarget ? `★${num}` : `${num}`;
      ctx.fillText(text, 0, 0);
      ctx.restore();
    });

    // 4. Inner Gold Rim
    ctx.beginPath();
    ctx.arc(cx, cy, R_pockets_inner, 0, 2 * Math.PI);
    ctx.strokeStyle = '#b45309';
    ctx.lineWidth = 2;
    ctx.stroke();

    // 5. Draw the golden/chromatic inner cone basin area
    const basinGrad = ctx.createRadialGradient(cx, cy, R_center_hub, cx, cy, R_pockets_inner);
    basinGrad.addColorStop(0, '#1e293b');
    basinGrad.addColorStop(0.5, '#0f172a');
    basinGrad.addColorStop(1, '#020617');
    ctx.beginPath();
    ctx.arc(cx, cy, R_pockets_inner, 0, 2 * Math.PI);
    ctx.fillStyle = basinGrad;
    ctx.fill();

    // 6. Draw Gold Spokes / Turret Lines radiating to pocket separators
    ctx.strokeStyle = 'rgba(180, 83, 9, 0.35)';
    ctx.lineWidth = 1;
    ROUE_ORDER.forEach((_, i) => {
      const sa = startOffset + i * sliceAngle;
      ctx.beginPath();
      ctx.moveTo(cx + R_inner_rim * Math.cos(sa), cy + R_inner_rim * Math.sin(sa));
      ctx.lineTo(cx + R_pockets_inner * Math.cos(sa), cy + R_pockets_inner * Math.sin(sa));
      ctx.stroke();
    });

    // 7. Draw the turret spokes ring (R_inner_rim)
    ctx.beginPath();
    ctx.arc(cx, cy, R_inner_rim, 0, 2 * Math.PI);
    ctx.strokeStyle = 'rgba(217, 119, 6, 0.8)';
    ctx.lineWidth = 1;
    ctx.stroke();

    // 8. Draw center golden metal hub (La tourelle)
    const activeHubGrad = ctx.createRadialGradient(cx - 3, cy - 3, 2, cx, cy, R_center_hub);
    activeHubGrad.addColorStop(0, '#fef08a');
    activeHubGrad.addColorStop(0.4, '#d97706');
    activeHubGrad.addColorStop(0.8, '#b45309');
    activeHubGrad.addColorStop(1, '#78350f');

    ctx.beginPath();
    ctx.arc(cx, cy, R_center_hub, 0, 2 * Math.PI);
    ctx.fillStyle = activeHubGrad;
    ctx.fill();
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 1.2;
    ctx.stroke();

    // Mini handles (cross spokes) in the center tourelle
    ctx.fillStyle = '#b45309';
    for (let axis = 0; axis < 4; axis++) {
      const angle = (axis * Math.PI) / 2;
      ctx.beginPath();
      ctx.arc(cx + (R_center_hub - 8) * Math.cos(angle), cy + (R_center_hub - 8) * Math.sin(angle), 2.5, 0, 2 * Math.PI);
      ctx.fill();
    }

    // 9. Draw the white Roulette Ball (Sleek 3D ball)
    if (lastDrawnNum !== null && activeBallAngle !== null) {
      const ballX = cx + activeBallRadius * Math.cos(activeBallAngle);
      const ballY = cy + activeBallRadius * Math.sin(activeBallAngle);

      // Metallic or white shining radial gradient
      const ballGrad = ctx.createRadialGradient(ballX - 2.5, ballY - 2.5, 1, ballX, ballY, 5);
      ballGrad.addColorStop(0, '#ffffff');
      ballGrad.addColorStop(0.3, '#f3f4f6');
      ballGrad.addColorStop(0.85, '#d1d5db');
      ballGrad.addColorStop(1, '#9ca3af');

      ctx.beginPath();
      ctx.arc(ballX, ballY, 5.5, 0, 2 * Math.PI);
      ctx.fillStyle = ballGrad;
      ctx.fill();
      
      // Shadow for real look
      ctx.shadowColor = 'rgba(0,0,0,0.6)';
      ctx.shadowBlur = 4;
      ctx.shadowOffsetX = 1;
      ctx.shadowOffsetY = 2.5;

      // Draw shiny ring
      ctx.beginPath();
      ctx.arc(ballX, ballY, 5.5, 0, 2 * Math.PI);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 0.5;
      ctx.stroke();

      // Clear shadow for other drawings
      ctx.shadowColor = 'transparent';
      ctx.shadowBlur = 0;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 0;
    }
  };

  return (
    <div className="flex flex-col items-center select-none bg-slate-950/25 p-3 rounded-2xl border border-slate-800/60 shadow-inner">
      <div className="flex gap-4 text-[10px] font-bold tracking-wider uppercase mb-2">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-red-600 block shadow-sm shadow-red-500/50"></span>
          <span className="text-slate-400">Rouges</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-slate-800 block"></span>
          <span className="text-slate-400">Noirs</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-yellow-500 block shadow-sm shadow-yellow-500/50"></span>
          <span className="text-yellow-400">★ À Jouer</span>
        </div>
      </div>

      <div className="relative">
        <canvas
          ref={canvasRef}
          width={220}
          height={220}
          className="rounded-full shadow-lg border border-slate-900 shadow-slate-950"
        />
        
        {/* Dynamic center coordinate indicator */}
        {lastDrawnNum !== null && (
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-slate-900 border border-slate-700/60 shadow flex items-center justify-center">
            <span className={`text-xs font-black ${
              lastDrawnNum === 0 
                ? 'text-emerald-400' 
                : RED_NUMBERS.includes(lastDrawnNum) 
                ? 'text-red-400' 
                : 'text-slate-100'
            }`}>
              {lastDrawnNum}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

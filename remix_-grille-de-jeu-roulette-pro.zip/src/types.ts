export type CellColor = 'white' | 'red' | 'green';

export interface GridState {
  [key: string]: CellColor; // key like "r-c"
}

export type NumberCoordinate = {
  isRight: boolean;
  r: number;
  c: number;
};

export interface CoupLog {
  id: string;
  playedNumbers: number[];
  win: boolean;
  winningNumber: number | null;
  miseTotal: number;
  gainTotal: number;
  net: number;
  balanceAfter: number;
}

export interface TableauState {
  id: number;
  numero: string;
  miseUnitaire: number;
  gainX: number;
  leftCells: GridState;
  rightCells: GridState;
  lastDrawnNum: number | null;
  coups: CoupLog[];
}

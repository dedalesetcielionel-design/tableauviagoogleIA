import { NumberCoordinate, GridState, CellColor } from '../types';
import { NUMBERS_LEFT, NUMBERS_RIGHT } from '../components/SquaresBoard';

export const ROUE_ORDER = [
  0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 
  10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26
];

export const RED_NUMBERS = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36];

export const TRANSVERSALES = [
  [1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15], [16, 17, 18],
  [19, 20, 21], [22, 23, 24], [25, 26, 27], [28, 29, 30], [31, 32, 33], [34, 35, 36]
];

// Helper to look up number in squares grids
export function findNumberCoordinates(num: number): NumberCoordinate | null {
  for (let r = 0; r < 6; r++) {
    const col = NUMBERS_LEFT[r].indexOf(num);
    if (col !== -1) return { isRight: false, r, c: col };
  }
  for (let r = 0; r < 6; r++) {
    const col = NUMBERS_RIGHT[r].indexOf(num);
    if (col !== -1) return { isRight: true, r, c: col };
  }
  return null;
}

// Check eligibility of a cell to stay Green ('★ À jouer')
export function isGreenEligible(cells: GridState, r: number, c: number): boolean {
  // Check row reds count
  let redsInRow = 0;
  for (let col = 0; col < 3; col++) {
    if (cells[`${r}-${col}`] === 'red') redsInRow++;
  }
  if (redsInRow === 2) return true;

  // Check column block reds count (blocks are row 0-2 and row 3-5)
  const blockRowStart = Math.floor(r / 3) * 3;
  let redsInColBlock = 0;
  for (let row = blockRowStart; row < blockRowStart + 3; row++) {
    if (cells[`${row}-${c}`] === 'red') redsInColBlock++;
  }
  return redsInColBlock === 2;
}

// Refreshes the color of green cells on a grid if they lost the reds criteria
export function refreshGreenStates(cells: GridState): GridState {
  const nextCells = { ...cells };
  Object.keys(nextCells).forEach((key) => {
    if (nextCells[key] === 'green') {
      const [r, c] = key.split('-').map(Number);
      if (!isGreenEligible(nextCells, r, c)) {
        nextCells[key] = 'white';
      }
    }
  });
  return nextCells;
}

// Check matching block logic & toggle green states if row or column contains 2 red cells
export function checkBlockAndApplyGreens(cells: GridState, r: number, c: number, isRight: boolean): GridState {
  let nextCells = { ...cells };
  const nums = isRight ? NUMBERS_RIGHT : NUMBERS_LEFT;
  const blockRowStart = Math.floor(r / 3) * 3;

  // 1. Check Row reds
  let redsInRow = 0;
  for (let col = 0; col < 3; col++) {
    if (nextCells[`${r}-${col}`] === 'red') redsInRow++;
  }
  if (redsInRow === 2) {
    for (let col = 0; col < 3; col++) {
      const key = `${r}-${col}`;
      if (nextCells[key] !== 'red' && nextCells[key] !== 'green') {
        nextCells[key] = 'green';
      }
    }
  }

  // 2. Check Column Block reds
  let redsInColBlock = 0;
  for (let row = blockRowStart; row < blockRowStart + 3; row++) {
    if (nextCells[`${row}-${c}`] === 'red') redsInColBlock++;
  }
  if (redsInColBlock === 2) {
    for (let row = blockRowStart; row < blockRowStart + 3; row++) {
      const key = `${row}-${c}`;
      if (nextCells[key] !== 'red' && nextCells[key] !== 'green') {
        nextCells[key] = 'green';
      }
    }
  }

  // 3. Clear green flag on any greens that are no longer eligible
  nextCells = refreshGreenStates(nextCells);

  return nextCells;
}

// Initial grid layout helper
export function initGridState(): GridState {
  const state: GridState = {};
  for (let r = 0; r < 6; r++) {
    for (let c = 0; c < 3; c++) {
      state[`${r}-${c}`] = 'white';
    }
  }
  return state;
}

// Extracts integers for active green state in a board
export function getActiveGreenNumbersForBoard(leftCells: GridState, rightCells: GridState): Set<number> {
  const greens = new Set<number>();
  
  Object.entries(leftCells).forEach(([key, color]) => {
    if (color === 'green') {
      const [r, c] = key.split('-').map(Number);
      greens.add(NUMBERS_LEFT[r][c]);
    }
  });

  Object.entries(rightCells).forEach(([key, color]) => {
    if (color === 'green') {
      const [r, c] = key.split('-').map(Number);
      greens.add(NUMBERS_RIGHT[r][c]);
    }
  });

  return greens;
}

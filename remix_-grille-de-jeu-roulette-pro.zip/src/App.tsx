import { useState, useMemo } from 'react';
import { 
  Sparkles, 
  RotateCcw, 
  Layers, 
  TrendingUp, 
  Hash, 
  HelpCircle,
  Coins, 
  AlertCircle,
  TrendingDown, 
  CheckCircle, 
  ArrowRight,
  ShieldAlert,
  Info,
  Download,
  Upload,
  FileDown,
  Laptop,
  X
} from 'lucide-react';

import { TableauState, CoupLog } from './types';
import { 
  initGridState, 
  findNumberCoordinates, 
  checkBlockAndApplyGreens, 
  getActiveGreenNumbersForBoard, 
  TRANSVERSALES,
  RED_NUMBERS 
} from './utils/gameUtils';

import KeypadTapis from './components/KeypadTapis';
import HistoryTicker from './components/HistoryTicker';
import SquaresBoard from './components/SquaresBoard';
import RouletteWheel from './components/RouletteWheel';

export default function App() {
  // Global configurations
  const [capitalInitial, setCapitalInitial] = useState<number>(1000);
  const [globalHistory, setGlobalHistory] = useState<number[]>([]);
  const [viewMode, setViewMode] = useState<'all' | '0' | '1' | '2'>('all');
  const [activeTableauIndex, setActiveTableauIndex] = useState<number>(0);
  const [isDeskGuideOpen, setIsDeskGuideOpen] = useState<boolean>(false);

  // Core 3-boards state
  const [tableaux, setTableaux] = useState<TableauState[]>([
    {
      id: 0,
      numero: 'Tableau 1',
      miseUnitaire: 5,
      gainX: 36,
      leftCells: initGridState(),
      rightCells: initGridState(),
      lastDrawnNum: null,
      coups: [],
    },
    {
      id: 1,
      numero: 'Tableau 2',
      miseUnitaire: 5,
      gainX: 36,
      leftCells: initGridState(),
      rightCells: initGridState(),
      lastDrawnNum: null,
      coups: [],
    },
    {
      id: 2,
      numero: 'Tableau 3',
      miseUnitaire: 5,
      gainX: 36,
      leftCells: initGridState(),
      rightCells: initGridState(),
      lastDrawnNum: null,
      coups: [],
    },
  ]);

  // Dynamic statistics calculations
  const frequencies = useMemo(() => {
    const freq: Record<number, number> = {};
    for (let i = 0; i <= 36; i++) freq[i] = 0;
    globalHistory.forEach((num) => {
      if (freq[num] !== undefined) freq[num]++;
    });
    return freq;
  }, [globalHistory]);

  const topTransversales = useMemo(() => {
    const transvScores = TRANSVERSALES.map((nums) => {
      const score = nums.reduce((acc, num) => acc + (frequencies[num] || 0), 0);
      return { nums, score };
    });
    // Sort descending by highest sum of occurrence, falls back to first number ascending
    return [...transvScores]
      .sort((a, b) => b.score - a.score || a.nums[0] - b.nums[0])
      .slice(0, 6);
  }, [frequencies]);

  const recommendedFulls = useMemo(() => {
    const maxFreq = Math.max(...(Object.values(frequencies) as number[]), 1);
    const topTransvNums = new Set(topTransversales.flatMap((t) => t.nums));

    // Calculate top hottest numbers apart from 0
    const hotNumbers = Object.entries(frequencies)
      .filter(([n]) => n !== '0')
      .map(([n, count]) => ({ num: Number(n), count: count as number }))
      .sort((a, b) => b.count - a.count || a.num - b.num)
      .slice(0, 6)
      .map((x) => x.num);
    const hotNumbersSet = new Set(hotNumbers);

    return Array.from({ length: 37 }, (_, i) => i)
      .filter((n) => n !== 0 && !hotNumbersSet.has(n))
      .map((num) => {
        const count = frequencies[num] || 0;
        const delayIndex = globalHistory.findIndex((v) => v === num);
        // Delay is the amount of spins since its last appearance
        const delay = delayIndex === -1 ? 50 : delayIndex;
        // Addition score if inside active high-probability transversals
        const transvBonus = topTransvNums.has(num) ? 2 : 0;
        const freqScore = 1 - count / maxFreq;
        const score = delay * 2 + freqScore * 5 + transvBonus * 3;
        return { num, score };
      })
      .sort((a, b) => b.score - a.score || a.num - b.num)
      .slice(0, 6)
      .map((x) => x.num);
  }, [frequencies, topTransversales, globalHistory]);

  // Master click selection handler
  const handleNumberSelected = (num: number) => {
    // Determine the active board
    const activeBoard = tableaux[activeTableauIndex];
    const coords = findNumberCoordinates(num);

    // 1. Push to global drawn history strips
    const updatedHistory = [num, ...globalHistory];
    setGlobalHistory(updatedHistory);

    // 2. Clone boards
    const nextTableaux = tableaux.map((board) => {
      if (board.id !== activeTableauIndex) {
        return board; // only change values for active board
      }

      // Check for targets (greens) *before* applying the new click
      const previousTargets = getActiveGreenNumbersForBoard(board.leftCells, board.rightCells);
      let updatedLeft = { ...board.leftCells };
      let updatedRight = { ...board.rightCells };

      // Toggle cell state if number exists in the left/right 6x3 grids
      if (coords) {
        const key = `${coords.r}-${coords.c}`;
        const currentVal = coords.isRight ? updatedRight[key] : updatedLeft[key];

        const nextVal = currentVal === 'green' ? 'red' : currentVal === 'red' ? 'white' : 'red';

        if (coords.isRight) {
          updatedRight[key] = nextVal;
          updatedRight = checkBlockAndApplyGreens(updatedRight, coords.r, coords.c, true);
        } else {
          updatedLeft[key] = nextVal;
          updatedLeft = checkBlockAndApplyGreens(updatedLeft, coords.r, coords.c, false);
        }
      }

      // 3. Automated Coup Balance Evaluation
      const nextCoups = [...board.coups];
      if (previousTargets.size > 0) {
        const hasWon = previousTargets.has(num);
        const miseTotal = board.miseUnitaire * previousTargets.size;
        const gainTotal = hasWon ? board.miseUnitaire * board.gainX : 0;
        const net = gainTotal - miseTotal;

        // Current balance before adding this coup
        const currentBalance = capitalInitial + nextCoups.reduce((acc, c) => acc + c.net, 0);

        const newLog: CoupLog = {
          id: Math.random().toString(36).substring(2, 9),
          playedNumbers: Array.from(previousTargets),
          win: hasWon,
          winningNumber: num,
          miseTotal,
          gainTotal,
          net,
          balanceAfter: currentBalance + net,
        };
        nextCoups.push(newLog);
      }

      return {
        ...board,
        leftCells: updatedLeft,
        rightCells: updatedRight,
        lastDrawnNum: num,
        coups: nextCoups,
      };
    });

    setTableaux(nextTableaux);
  };

  // Click on Grid cell directly inside a given board
  const handleGridCellClick = (boardId: number, isRight: boolean, r: number, c: number) => {
    // Set this board as active
    setActiveTableauIndex(boardId);

    // Retrieve corresponding value from the grids
    const nums = isRight ? 
      [ [14, 9, 18], [32, 19, 21], [36, 30, 23], [7, 12, 3], [25, 34, 27], [5, 16, 1] ] :
      [ [31, 22, 29], [15, 4, 2], [11, 8, 10], [28, 35, 26], [17, 6, 13], [24, 33, 20] ];

    const valueNum = nums[r][c];
    // Trigger master click handler reflecting identical behavior
    handleNumberSelected(valueNum);
  };

  // Add losing coup manually: triggers loss calculation over active green numbers
  const handleAddLosingCoup = (boardId: number) => {
    const board = tableaux[boardId];
    const targets = getActiveGreenNumbersForBoard(board.leftCells, board.rightCells);

    if (targets.size === 0) {
      alert("Il n'y a aucun numéro vert actif à jouer sur ce tableau.");
      return;
    }

    const nextTableaux = tableaux.map((b) => {
      if (b.id !== boardId) return b;

      const miseTotal = b.miseUnitaire * targets.size;
      const net = -miseTotal;
      const currentBalance = capitalInitial + b.coups.reduce((acc, c) => acc + c.net, 0);

      const newLog: CoupLog = {
        id: Math.random().toString(36).substring(2, 9),
        playedNumbers: Array.from(targets),
        win: false,
        winningNumber: null,
        miseTotal,
        gainTotal: 0,
        net,
        balanceAfter: currentBalance + net,
      };

      return {
        ...b,
        coups: [...b.coups, newLog],
      };
    });

    setTableaux(nextTableaux);
  };

  // Reset a single board's cell state & coups
  const handleResetBoard = (boardId: number) => {
    if (!confirm(`Réinitialiser le Tableau ${boardId + 1} ? (Effacera les cases et les gains)`)) {
      return;
    }

    setTableaux(
      tableaux.map((b) => {
        if (b.id !== boardId) return b;
        return {
          ...b,
          leftCells: initGridState(),
          rightCells: initGridState(),
          lastDrawnNum: null,
          coups: [],
        };
      })
    );
  };

  // Undo the last logged coup balance item for a board
  const handleUndoCoup = (boardId: number) => {
    setTableaux(
      tableaux.map((b) => {
        if (b.id !== boardId) return b;
        if (b.coups.length === 0) return b;
        const nextCoups = [...b.coups];
        nextCoups.pop();
        return {
          ...b,
          coups: nextCoups,
        };
      })
    );
  };

  // Export active tracking state and ledger data as JSON to Desktop
  const handleExportSessionJSON = () => {
    try {
      const stateObj = {
        capitalInitial,
        globalHistory,
        tableaux
      };
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(stateObj, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", `roulette_pro_session_${new Date().toISOString().slice(0, 10)}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
    } catch (err) {
      alert("Erreur lors de l'exportation de la session.");
    }
  };

  // Import tracking state and ledger data from JSON file from Desktop
  const handleImportSessionJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (e.target.files && e.target.files[0]) {
      fileReader.readAsText(e.target.files[0], "UTF-8");
      fileReader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          if (parsed && typeof parsed === 'object') {
            if (parsed.capitalInitial !== undefined) setCapitalInitial(Number(parsed.capitalInitial));
            if (Array.isArray(parsed.globalHistory)) setGlobalHistory(parsed.globalHistory);
            if (Array.isArray(parsed.tableaux)) setTableaux(parsed.tableaux);
            alert("✅ Session importée avec succès ! Les tableaux, l'historique et les balances ont été restaurés.");
          } else {
            alert("Le fichier de sauvegarde est invalide.");
          }
        } catch (err) {
          alert("Erreur de décodage JSON : le fichier semble corrompu.");
        }
      };
    }
  };

  // Export ledger history of all cards to CSV for Excel / Calc
  const handleExportCSV = () => {
    try {
      let csvContent = "\uFEFF"; // Byte Order Mark for Excel UTF-8 display compatibility
      csvContent += "Tableau,Numero Coup,Mise Totale,Gains,Net,Balance Apres,Numero Tire,Numeros Joues\n";
      
      tableaux.forEach((board) => {
        board.coups.forEach((coup, idx) => {
          const played = (coup.playedNumbers || []).join(';');
          csvContent += `"${board.numero || `Tableau ${board.id + 1}`}",${idx + 1},${coup.miseTotal},${coup.gainTotal},${coup.net},${coup.balanceAfter},${coup.winningNumber ?? 'Perdu'},"${played}"\n`;
        });
      });

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", url);
      downloadAnchor.setAttribute("download", `roulette_pro_rapport_session_${new Date().toISOString().slice(0, 10)}.csv`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      alert("Erreur lors de la génération du CSV.");
    }
  };

  // Reset ALL states
  const handleGlobalReset = () => {
    if (!confirm('Réinitialiser globalement TOUS les tableaux, l\'historique et les balances ?')) {
      return;
    }
    setGlobalHistory([]);
    setCapitalInitial(1000);
    setTableaux(
      tableaux.map((b) => ({
        ...b,
        leftCells: initGridState(),
        rightCells: initGridState(),
        lastDrawnNum: null,
        coups: [],
      }))
    );
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Header Bar */}
      <header className="border-b border-slate-900 bg-slate-900/60 backdrop-blur sticky top-0 z-50 px-4 py-3 shadow-md">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 to-indigo-400 flex items-center justify-center shadow-md shadow-indigo-600/25">
              <Sparkles className="w-5 h-5 text-white animate-pulse" />
            </div>
            <div>
              <h1 className="text-sm font-black tracking-widest uppercase bg-gradient-to-r from-slate-100 to-slate-400 bg-clip-text text-transparent">
                Grille de Jeu Roulette Pro
              </h1>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                Analyseur Tactique et Repérage Visuel de Transversales
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-wrap">
            {/* Base Capital globally shared setting */}
            <div className="flex items-center gap-2 bg-slate-950/80 border border-slate-800 rounded-xl px-3 py-1.5">
              <Coins className="w-4 h-4 text-emerald-400" />
              <label className="text-[10px] text-slate-500 font-bold uppercase tracking-wide">
                Capital base :
              </label>
              <input
                type="number"
                value={capitalInitial || ''}
                placeholder="1000"
                onChange={(e) => setCapitalInitial(parseFloat(e.target.value) || 0)}
                className="w-20 bg-transparent border-0 font-mono font-bold text-xs text-emerald-400 focus:outline-none focus:ring-0 p-0 text-right"
              />
              <span className="text-xs text-emerald-500">€</span>
            </div>

            {/* Global Reset */}
            <button
              onClick={handleGlobalReset}
              className="flex items-center gap-1 text-xs font-bold px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-red-400 hover:bg-slate-900 transition shadow-sm"
              title="RAZ globale de la session"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Réimp. Globale</span>
            </button>

            {/* Separator */}
            <span className="hidden md:inline text-slate-800">|</span>

            {/* Export CSV Report */}
            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1 text-xs font-bold px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-emerald-450 hover:bg-slate-900 transition shadow-sm"
              title="Télécharger le rapport de gains et de pertes en format Excel (CSV) sur votre bureau"
            >
              <FileDown className="w-3.5 h-3.5 text-emerald-400" />
              <span>Rapport Excel</span>
            </button>

            {/* Save Complete State */}
            <button
              onClick={handleExportSessionJSON}
              className="flex items-center gap-1 text-xs font-bold px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-indigo-400 hover:bg-slate-900 transition shadow-sm"
              title="Sauvegarder l'état complet de vos 3 tableaux sur votre bureau"
            >
              <Download className="w-3.5 h-3.5 text-indigo-400" />
              <span>Sauver Session</span>
            </button>

            {/* Load Back Complete State */}
            <label
              className="flex items-center gap-1 text-xs font-bold px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-400 hover:text-blue-400 hover:bg-slate-900 cursor-pointer transition shadow-sm"
              title="Charger une sauvegarde roulette (.json) depuis votre bureau"
            >
              <Upload className="w-3.5 h-3.5 text-blue-400" />
              <span>Charger Session</span>
              <input
                type="file"
                accept=".json"
                onChange={handleImportSessionJSON}
                className="hidden"
              />
            </label>

            {/* Desktop App download helper and instructions */}
            <button
              onClick={() => setIsDeskGuideOpen(true)}
              className="flex items-center gap-1 text-xs font-bold px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-550 text-white shadow-md transition-all duration-200"
              title="Voir comment exporter et installer l'application sur votre bureau"
            >
              <Laptop className="w-3.5 h-3.5" />
              <span>Installer l'App 💻</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Workspace Frame */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 flex flex-col gap-6">
        
        {/* Row 1: Keypad + Help */}
        <section className="grid grid-cols-1 lg:grid-cols-4 gap-4 items-stretch">
          <div className="lg:col-span-3">
            <KeypadTapis
              onNumberSelect={handleNumberSelected}
              topTransversales={topTransversales}
              recommendedFulls={recommendedFulls}
              frequencies={frequencies}
            />
          </div>

          <div className="bg-slate-900 rounded-2xl border border-slate-800 p-4 flex flex-col justify-between">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-slate-300">
                <Info className="w-4 h-4 text-indigo-400" />
                <h3 className="text-xs font-black uppercase tracking-wider">Note Méthodologique</h3>
              </div>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                Le pavé interactif et les carrés convergent directement vers la roue. 
                Sélectionner un chiffre positionne la bille dessus et gère les sélections de l'ensemble des 3 tableaux actifs.
              </p>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                Lorsqu'une transversale (colonne T1 à T12) s'illumine en <span className="text-amber-400 font-semibold">Gold</span>, elle fait partie du haut classement des tirages prioritaires à exploiter.
              </p>
            </div>
            
            <div className="mt-4 pt-4 border-t border-slate-850 flex items-center gap-2 text-[10px] text-slate-500 font-bold uppercase transition">
              <span className="w-2 h-2 rounded-full bg-indigo-500 animate-ping"></span>
              <span>Analyseur Actif en Temps Réel</span>
            </div>
          </div>
        </section>

        {/* Dynamic history strip bar */}
        <section>
          <HistoryTicker
            history={globalHistory}
            onClearHistory={() => setGlobalHistory([])}
          />
        </section>

        {/* Tab Selection Row */}
        <section className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-900 pb-2">
          <div className="flex gap-1 bg-slate-950 border border-slate-850 p-1 rounded-xl">
            <button
              onClick={() => setViewMode('all')}
              className={`text-xs font-bold px-4 py-2 rounded-lg transition-all ${
                viewMode === 'all'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Tous les Tableaux
            </button>
            <button
              onClick={() => {
                setViewMode('0');
                setActiveTableauIndex(0);
              }}
              className={`text-xs font-bold px-4 py-2 rounded-lg transition-all ${
                viewMode === '0'
                  ? 'bg-indigo-600 text-white shadow shadow-indigo-600/35'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Tableau 1
            </button>
            <button
              onClick={() => {
                setViewMode('1');
                setActiveTableauIndex(1);
              }}
              className={`text-xs font-bold px-4 py-2 rounded-lg transition-all ${
                viewMode === '1'
                  ? 'bg-indigo-600 text-white shadow shadow-indigo-600/35'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Tableau 2
            </button>
            <button
              onClick={() => {
                setViewMode('2');
                setActiveTableauIndex(2);
              }}
              className={`text-xs font-bold px-4 py-2 rounded-lg transition-all ${
                viewMode === '2'
                  ? 'bg-indigo-600 text-white shadow shadow-indigo-600/35'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Tableau 3
            </button>
          </div>

          <div className="flex items-center gap-2 text-xs font-bold text-slate-400">
            <Layers className="w-4 h-4 text-indigo-400" />
            <span>Tableau actif pour le pavé : </span>
            <span className="text-white bg-slate-800 px-2.5 py-0.5 rounded-md font-mono">
              Tableau {activeTableauIndex + 1}
            </span>
          </div>
        </section>

        {/* Grid of Micro-Board Cards */}
        <section className="flex flex-col gap-6">
          {tableaux
            .filter((board) => viewMode === 'all' || viewMode === board.id.toString())
            .map((board) => {
              const isActive = activeTableauIndex === board.id;
              const targets = getActiveGreenNumbersForBoard(board.leftCells, board.rightCells);
              const totalBetAmount = board.miseUnitaire * targets.size;
              
              const totalGain = board.coups.reduce((acc, c) => acc + c.gainTotal, 0);
              const totalSpent = board.coups.reduce((acc, c) => acc + c.miseTotal, 0);
              const currentBalance = capitalInitial + (totalGain - totalSpent);
              const diffBase = currentBalance - capitalInitial;

              return (
                <div
                  key={board.id}
                  onClick={() => {
                    if (!isActive) setActiveTableauIndex(board.id);
                  }}
                  className={`bg-slate-900 rounded-3xl border transition-all ${
                    isActive 
                      ? 'border-indigo-500 shadow-xl shadow-indigo-950/20 ring-2 ring-indigo-950 bg-slate-900' 
                      : 'border-slate-800/80 hover:border-slate-755 hover:bg-slate-900/80 saturate-95 duration-200'
                  }`}
                >
                  {/* Card Header stats & modifiers */}
                  <div className="border-b border-slate-850 px-5 py-4 flex flex-wrap items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-lg font-mono font-black text-xs flex items-center justify-center border ${
                        isActive 
                        ? 'bg-indigo-600 border-indigo-500 text-white' 
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                      }`}>
                        T{board.id + 1}
                      </div>
                      
                      {/* Custom board name reference */}
                      <input
                        type="text"
                        value={board.numero}
                        onChange={(e) => {
                          const val = e.target.value;
                          setTableaux(tableaux.map((b) => b.id === board.id ? { ...b, numero: val } : b));
                        }}
                        placeholder={`Tableau ${board.id + 1}`}
                        className="bg-transparent border-b border-slate-800 hover:border-slate-700 font-bold shrink text-sm focus:outline-none focus:border-indigo-500 p-0.5 text-slate-100 max-w-28"
                      />

                      {/* Targeted number counts */}
                      <span className="text-[10px] bg-slate-950 border border-slate-800 px-2 py-0.5 rounded-full font-mono font-bold text-slate-400">
                        {targets.size} vert(s)
                      </span>
                    </div>

                    {/* Quick modifiers: Unitary stake and multiplier factor */}
                    <div className="flex flex-wrap items-center gap-3">
                      <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-850 rounded-lg px-2.5 py-1">
                        <label className="text-[9px] text-slate-500 font-bold uppercase tracking-wide">Mise :</label>
                        <input
                          type="number"
                          value={board.miseUnitaire || ''}
                          placeholder="5"
                          className="w-10 bg-transparent border-0 font-mono font-bold text-xs text-slate-100 focus:outline-none focus:ring-0 p-0 text-right"
                          onChange={(e) => {
                            const val = parseFloat(e.target.value) || 0;
                            setTableaux(tableaux.map((b) => b.id === board.id ? { ...b, miseUnitaire: val } : b));
                          }}
                        />
                        <span className="text-[10px] text-slate-400">€</span>
                      </div>

                      <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-850 rounded-lg px-2.5 py-1">
                        <label className="text-[9px] text-slate-500 font-bold uppercase tracking-wide">Gain X :</label>
                        <input
                          type="number"
                          value={board.gainX || ''}
                          placeholder="36"
                          className="w-8 bg-transparent border-0 font-mono font-bold text-xs text-slate-100 focus:outline-none focus:ring-0 p-0 text-right"
                          onChange={(e) => {
                            const val = parseFloat(e.target.value) || 0;
                            setTableaux(tableaux.map((b) => b.id === board.id ? { ...b, gainX: val } : b));
                          }}
                        />
                      </div>

                      {/* Dynamic balance ticker for this card */}
                      <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg font-mono font-bold text-xs border ${
                        diffBase > 0 
                          ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' 
                          : diffBase < 0 
                          ? 'bg-rose-500/10 border-rose-500/30 text-rose-400' 
                          : 'bg-slate-950 border-slate-850 text-slate-400'
                      }`}>
                        <span>B:</span>
                        <span>{currentBalance.toFixed(2)} €</span>
                        <span className="text-[10px] opacity-80">
                          ({diffBase >= 0 ? `+${diffBase.toFixed(1)}` : `${diffBase.toFixed(1)}`})
                        </span>
                      </div>
                    </div>

                    {/* Operational controls */}
                    <div className="flex gap-2.5">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleAddLosingCoup(board.id);
                        }}
                        className="text-[10px] font-black tracking-wider uppercase px-2.5 py-1.5 border border-rose-800/60 bg-rose-950/20 hover:bg-rose-900/20 text-rose-300 rounded-lg transition"
                        title="Ajouter un coup perdant sans modifier les cases"
                      >
                        ❌ Coup Perdant
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleUndoCoup(board.id);
                        }}
                        className="text-[10px] font-black tracking-wider uppercase px-2.5 py-1.5 border border-slate-855 bg-slate-950 hover:bg-slate-850 text-slate-350 rounded-lg transition"
                        title="Annuler la dernière balance enregistrée"
                      >
                        ⌫ Annuler
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleResetBoard(board.id);
                        }}
                        className="text-[10px] font-black tracking-wider uppercase px-2.5 py-1.5 bg-slate-950 hover:bg-slate-850 border border-slate-800 text-slate-450 hover:text-white rounded-lg transition"
                        title="Remise à zéro des cases de ce tableau"
                      >
                        RAZ
                      </button>
                    </div>
                  </div>

                  {/* Card Body panels: Squares Board on left/center, Roulette wheel on right */}
                  <div className="p-5 flex flex-col xl:flex-row gap-6 items-center lg:items-stretch justify-center">
                    
                    {/* Visual Frame 1: Squares board grids */}
                    <div className="flex-1 flex flex-col justify-center">
                      <SquaresBoard
                        leftCells={board.leftCells}
                        rightCells={board.rightCells}
                        onCellClick={(isRight, r, c) => handleGridCellClick(board.id, isRight, r, c)}
                      />
                    </div>

                    {/* Visual Frame 2: Roulette wheel display */}
                    <div className="shrink-0 flex items-center justify-center">
                      <RouletteWheel
                        lastDrawnNum={board.lastDrawnNum}
                        targetNumbers={targets}
                        historyCount={globalHistory.length}
                      />
                    </div>
                  </div>

                  {/* Card Footer panel: Compact ledger logs */}
                  <div className="bg-slate-950/40 border-t border-slate-850/60 px-5 py-3 rounded-b-3xl">
                    <div className="flex items-center justify-between gap-4 flex-wrap">
                      <div className="flex items-center gap-2 text-slate-500 text-[10px] font-bold uppercase">
                        <ArrowRight className="w-3.5 h-3.5 text-indigo-500" />
                        <span>Derniers coups de ce Tableau :</span>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        {board.coups.length === 0 ? (
                          <span className="text-[10px] text-slate-600 italic">Aucun coup enregistré. Activez des cases vertes puis faites un tirage.</span>
                        ) : (
                          board.coups.slice(-5).reverse().map((coup, idx) => (
                            <div
                              key={idx}
                              className={`text-[10px] font-mono px-2.5 py-1 rounded-md border flex items-center gap-1.5 ${
                                coup.win
                                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                                  : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                              }`}
                            >
                              <span className="font-bold opacity-60">
                                #{board.coups.length - idx}
                              </span>
                              <span>
                                {coup.winningNumber === null 
                                  ? 'Perdu (Sér.)' 
                                  : `N°${coup.winningNumber} (${coup.win ? 'Gains' : 'Pertes'})`
                                }
                              </span>
                              <span className="font-bold">
                                {coup.net >= 0 ? `+${coup.net.toFixed(0)}` : `${coup.net.toFixed(0)}`}€
                              </span>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
        </section>
      </main>

      {/* Footer Branding */}
      <footer className="border-t border-slate-900 bg-slate-950 py-6 px-4 mt-12 text-center text-slate-500 text-xs">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="font-medium text-[10px] uppercase tracking-wider text-slate-650">
            Grille de Jeu Roulette Pro V3 — Concepteur Tactique Roulette &copy; 2026
          </p>
          <div className="flex items-center gap-2 text-[10px] tracking-wide text-slate-600 font-bold uppercase">
            <ShieldAlert className="w-3.5 h-3.5 text-slate-600" />
            <span>Réservé à un usage expérimental et récréatif</span>
          </div>
        </div>
      </footer>

      {/* Visual Guide Modal for Desktop Download / Installation */}
      {isDeskGuideOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 shadow-2xl relative">
            <button
              onClick={() => setIsDeskGuideOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-100 bg-slate-950 border border-slate-850 rounded-full p-1.5 transition cursor-pointer"
              title="Fermer"
            >
              <X className="w-4 h-4" />
            </button>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-indigo-650/20 flex items-center justify-center border border-indigo-500/30">
                <Laptop className="w-5 h-5 text-indigo-400" />
              </div>
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-slate-100">
                  Installer l'application sur votre Bureau
                </h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                  Comment télécharger et lancer l'application en local
                </p>
              </div>
            </div>

            <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
              <p>
                Pour installer et lancer l'application <strong>Grille de Jeu Roulette Pro</strong> de façon autonome directement sur votre ordinateur (Windows, Mac ou Linux), suivez ces étapes rapides :
              </p>

              <div className="bg-slate-950/80 rounded-2xl p-4 border border-slate-850 space-y-3 font-medium">
                <div className="flex gap-2.5">
                  <span className="text-white bg-indigo-600 w-5 h-5 rounded-full flex items-center justify-center shrink-0 text-[10px] font-bold">1</span>
                  <p>
                    Regardez en haut à droite de l'écran ou dans le menu de votre projet Google AI Studio, puis cliquez sur <strong>Export to ZIP</strong> (ou exportez vers GitHub).
                  </p>
                </div>
                <div className="flex gap-2.5">
                  <span className="text-white bg-indigo-600 w-5 h-5 rounded-full flex items-center justify-center shrink-0 text-[10px] font-bold">2</span>
                  <p>
                    Décompressez l'archive ZIP téléchargée dans un dossier sur votre bureau (par exemple <code>RoulettePro</code>).
                  </p>
                </div>
                <div className="flex gap-2.5">
                  <span className="text-white bg-indigo-650 w-5 h-5 rounded-full flex items-center justify-center shrink-0 text-[10px] font-bold">3</span>
                  <div className="w-full">
                    <p>
                      Ouvrez votre console de commande (Terminal) dans ce dossier et lancez le serveur :
                    </p>
                    <code className="block bg-slate-900 border border-slate-850 p-2 rounded-lg text-indigo-450 text-[11px] font-mono mt-1.5 select-all">
                      npm install<br />
                      npm run dev
                    </code>
                  </div>
                </div>
                <div className="flex gap-2.5">
                  <span className="text-white bg-indigo-600 w-5 h-5 rounded-full flex items-center justify-center shrink-0 text-[10px] font-bold">4</span>
                  <p>
                    Votre navigateur ouvrira automatiquement l'application sur <code>http://localhost:3000</code>. Le tracker de roulette est alors entièrement autonome et exécuté sur votre bureau !
                  </p>
                </div>
              </div>

              <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3 flex gap-2.5">
                <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <p className="text-[11px] text-emerald-300">
                  <strong>Astuce de sauvegarde :</strong> Pensez à utiliser régulièrement les boutons <strong>Sauver Session</strong> (fichier .json) et <strong>Rapport Excel</strong> (fichier .csv) présents dans l'en-tête pour conserver vos historiques de tirages roulette sur votre bureau et les ré-importer plus tard.
                </p>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setIsDeskGuideOpen(false)}
                className="px-5 py-2 rounded-xl bg-slate-800 text-slate-100 text-xs font-bold hover:bg-slate-750 transition cursor-pointer"
              >
                C'est noté !
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
